import { EventKind, createTokenState } from './domain.js';

const clamp = (value, min = 0, max = 100) => Math.max(min, Math.min(max, value));

function poolExitLiquidity(token) {
  return Object.values(token.pools).reduce((sum, pool) => sum + Math.max(0, pool.exitLiquidityUsd || 0), 0);
}

function hardBlocks(token) {
  const blocks = [];
  if (!token.technical.created) blocks.push('token_not_created');
  if (token.technical.mintAuthorityActive) blocks.push('mint_authority_active');
  if (token.technical.freezeAuthorityActive) blocks.push('freeze_authority_active');
  if (token.technical.postLaunchMint) blocks.push('post_launch_mint');
  if (token.technical.transferHook || token.technical.transferFeeBps > 0) blocks.push('restricted_transfer_mechanism');
  if (token.technical.unsupportedTokenProgram) blocks.push('unsupported_token_program');
  if (token.lifecycle.liquidityRemoved) blocks.push('liquidity_removed');
  return blocks;
}

export function snapshot(token) {
  const exitLiquidityUsd = poolExitLiquidity(token);
  const blocks = hardBlocks(token);
  const holderConcentration = token.holderSnapshot.length === 0
    ? 1
    : Math.max(...token.holderSnapshot.map((holder) => holder.share));
  const totalFlow = token.flow.buyUsd + token.flow.sellUsd;
  const sellPressure = totalFlow === 0 ? 0 : Math.round((token.flow.sellUsd / totalFlow) * 100);
  const strongClusters = Object.values(token.flow.buyers)
    .filter((buyer) => buyer.quality >= 0.75 && buyer.netBuyUsd > 0).length;
  const safetyScore = blocks.length > 0 ? 0 : clamp(92 - (holderConcentration > 0.35 ? (holderConcentration - 0.35) * 120 : 0));
  const creatorScore = token.creator.historyScore === null ? 45 : clamp(token.creator.historyScore * 100);
  const demandScore = clamp(
    18 + Math.sqrt(Math.max(0, token.flow.buyUsd - token.flow.sellUsd)) * 0.65 + strongClusters * 15 - sellPressure * 0.35,
  );
  const narrativeScore = clamp(
    token.narrative.mentionAcceleration * 60 + token.narrative.authorsQuality * 30
      + (token.narrative.semanticMatch ? 10 : 0) - token.narrative.coordinationRisk * 55,
  );
  const graduationProbability = clamp(
    0.25 * demandScore + 0.2 * narrativeScore + Math.min(exitLiquidityUsd / 250, 20)
      + strongClusters * 4 - sellPressure * 0.2 - holderConcentration * 25,
  );

  let decision = 'observe';
  let positionMultiplier = 0;
  if (blocks.length > 0) {
    decision = 'reject';
  } else if (
    safetyScore >= 75 && creatorScore >= 60 && demandScore >= 55 && narrativeScore >= 45
    && exitLiquidityUsd >= 5_000 && holderConcentration <= 0.35 && strongClusters >= 2
  ) {
    decision = 'confirmed_entry';
    positionMultiplier = 1;
  } else if (
    token.creator.historyScore === null && safetyScore >= 85 && demandScore >= 45
    && narrativeScore >= 65 && token.narrative.globalEventMatch && exitLiquidityUsd >= 8_000
  ) {
    decision = 'probe_entry';
    positionMultiplier = 0.2;
  }

  return {
    mint: token.mint,
    hardBlocks: blocks,
    safetyScore: Math.round(safetyScore),
    creatorScore: Math.round(creatorScore),
    demandScore: Math.round(demandScore),
    narrativeScore: Math.round(narrativeScore),
    holderConcentration: Number(holderConcentration.toFixed(4)),
    sellPressure,
    exitLiquidityUsd: Number(exitLiquidityUsd.toFixed(2)),
    graduationProbability: Math.round(graduationProbability),
    independentStrongClusters: strongClusters,
    decision,
    positionMultiplier,
  };
}

export function applyEvent(replayState, event) {
  const { payload } = event;
  const token = replayState.tokens[payload.mint] ?? createTokenState(payload.mint);
  replayState.tokens[payload.mint] = token;

  switch (event.kind) {
    case EventKind.TOKEN_CREATED:
      token.technical.created = true;
      token.creator = { clusterId: payload.creatorClusterId ?? null, historyScore: payload.creatorHistoryScore ?? null };
      Object.assign(token.technical, {
        mintAuthorityActive: Boolean(payload.mintAuthorityActive),
        freezeAuthorityActive: Boolean(payload.freezeAuthorityActive),
        transferHook: Boolean(payload.transferHook),
        transferFeeBps: Number(payload.transferFeeBps ?? 0),
        unsupportedTokenProgram: Boolean(payload.unsupportedTokenProgram),
      });
      break;
    case EventKind.METADATA_CREATED:
      token.metadata = {
        created: true,
        socialLinks: [...new Set(payload.socialLinks ?? [])].sort(),
      };
      break;
    case EventKind.MINT_TO:
      // Initial supply creation is normal; any later mint is a fail-closed event.
      token.technical.postLaunchMint ||= !Boolean(payload.initialSupply);
      break;
    case EventKind.AUTHORITY_CHANGED:
      if (payload.authority === 'mint') token.technical.mintAuthorityActive = Boolean(payload.active);
      if (payload.authority === 'freeze') token.technical.freezeAuthorityActive = Boolean(payload.active);
      break;
    case EventKind.POOL_CREATED:
      token.pools[payload.poolId] = { exitLiquidityUsd: Number(payload.exitLiquidityUsd ?? payload.initialLiquidityUsd ?? 0) };
      break;
    case EventKind.CURVE_CREATED:
      token.lifecycle.curveCreated = true;
      break;
    case EventKind.LIQUIDITY_ADDED:
      token.pools[payload.poolId] ??= { exitLiquidityUsd: 0 };
      token.pools[payload.poolId].exitLiquidityUsd += Number(payload.amountUsd ?? 0);
      break;
    case EventKind.LIQUIDITY_REMOVED:
      token.pools[payload.poolId] ??= { exitLiquidityUsd: 0 };
      token.pools[payload.poolId].exitLiquidityUsd = Math.max(0, token.pools[payload.poolId].exitLiquidityUsd - Number(payload.amountUsd ?? 0));
      token.lifecycle.liquidityRemoved ||= Boolean(payload.allLiquidityRemoved);
      break;
    case EventKind.BUY:
      token.flow.buyUsd += Number(payload.amountUsd ?? 0);
      if (payload.buyerClusterId) {
        const buyer = token.flow.buyers[payload.buyerClusterId] ?? { quality: 0, netBuyUsd: 0 };
        buyer.quality = Math.max(buyer.quality, Number(payload.buyerQuality ?? 0));
        buyer.netBuyUsd += Number(payload.amountUsd ?? 0);
        token.flow.buyers[payload.buyerClusterId] = buyer;
      }
      break;
    case EventKind.SELL:
      token.flow.sellUsd += Number(payload.amountUsd ?? 0);
      if (payload.sellerClusterId && token.flow.buyers[payload.sellerClusterId]) {
        token.flow.buyers[payload.sellerClusterId].netBuyUsd -= Number(payload.amountUsd ?? 0);
      }
      break;
    case EventKind.TOKEN_TRANSFER:
      token.transferCount += 1;
      break;
    case EventKind.HOLDER_SNAPSHOT:
      token.holderSnapshot = [...(payload.holders ?? [])]
        .map(({ clusterId, share }) => ({ clusterId, share: Number(share) }))
        .sort((a, b) => a.clusterId.localeCompare(b.clusterId));
      break;
    case EventKind.NARRATIVE_UPDATED:
      token.narrative = {
        mentionAcceleration: Number(payload.mentionAcceleration ?? 0),
        authorsQuality: Number(payload.authorsQuality ?? 0),
        semanticMatch: Boolean(payload.semanticMatch),
        coordinationRisk: Number(payload.coordinationRisk ?? 0),
        globalEventMatch: Boolean(payload.globalEventMatch),
      };
      break;
    case EventKind.GRADUATION:
      token.lifecycle.graduated = true;
      break;
    case EventKind.MIGRATION:
      token.lifecycle.migrated = true;
      break;
    default:
      break;
  }
  replayState.appliedEvents += 1;
  return snapshot(token);
}
