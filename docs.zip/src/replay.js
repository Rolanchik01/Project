import { orderedEvents, createReplayState } from './domain.js';
import { applyEvent } from './risk-engine.js';

/** Runs the paper-only state machine. A version mismatch throws and stops replay. */
export function replay(events, adapterRegistry) {
  const state = createReplayState();
  const timeline = [];
  for (const event of orderedEvents(events)) {
    adapterRegistry.assertCompatible(event);
    const risk = applyEvent(state, event);
    timeline.push({ eventId: event.id, slot: event.slot, kind: event.kind, risk });
  }
  return { state, timeline };
}
