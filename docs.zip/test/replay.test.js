import assert from 'node:assert/strict';
import test from 'node:test';
import { AdapterRegistry, AdapterVersionMismatch } from '../src/adapter-contract.js';
import { EventKind, Venue } from '../src/domain.js';
import { replay } from '../src/replay.js';

const version = 'pump-layout-2026-08';
const registry = () => new AdapterRegistry().register(Venue.PUMP, version);
const base = (id, slot, kind, payload) => ({
  id, slot, observedAtNs: String(slot * 1_000), signature: `sig-${slot}`, instructionIndex: 0,
  venue: Venue.PUMP, programVersion: version, kind, payload: { mint: 'MintA', ...payload },
});

function confirmedCandidateEvents() {
  return [
    base('token', 1, EventKind.TOKEN_CREATED, { creatorClusterId: 'creator', creatorHistoryScore: 0.84 }),
    base('pool', 2, EventKind.POOL_CREATED, { poolId: 'pool-1', initialLiquidityUsd: 12_000 }),
    base('holders', 3, EventKind.HOLDER_SNAPSHOT, { holders: [{ clusterId: 'a', share: 0.19 }, { clusterId: 'b', share: 0.13 }] }),
    base('buy-1', 4, EventKind.BUY, { buyerClusterId: 'smart-a', buyerQuality: 0.91, amountUsd: 3_000 }),
    base('buy-2', 5, EventKind.BUY, { buyerClusterId: 'smart-b', buyerQuality: 0.88, amountUsd: 2_000 }),
    base('narrative', 6, EventKind.NARRATIVE_UPDATED, { mentionAcceleration: 0.82, authorsQuality: 0.78, semanticMatch: true, coordinationRisk: 0.08 }),
  ];
}

test('replay is deterministic and confirms a safe candidate backed by two independent clusters', () => {
  const normal = replay(confirmedCandidateEvents(), registry());
  const shuffled = replay([...confirmedCandidateEvents()].reverse(), registry());
  const first = normal.timeline.at(-1).risk;
  const second = shuffled.timeline.at(-1).risk;
  assert.deepEqual(first, second);
  assert.equal(first.decision, 'confirmed_entry');
  assert.equal(first.independentStrongClusters, 2);
  assert.equal(first.hardBlocks.length, 0);
});

test('a new creator with a strong matched global narrative receives only probe size', () => {
  const events = [
    base('token', 1, EventKind.TOKEN_CREATED, { creatorClusterId: 'unknown', creatorHistoryScore: null }),
    base('pool', 2, EventKind.POOL_CREATED, { poolId: 'pool-1', initialLiquidityUsd: 10_000 }),
    base('holders', 3, EventKind.HOLDER_SNAPSHOT, { holders: [{ clusterId: 'a', share: 0.2 }] }),
    base('buy', 4, EventKind.BUY, { buyerClusterId: 'smart-a', buyerQuality: 0.9, amountUsd: 2_000 }),
    base('narrative', 5, EventKind.NARRATIVE_UPDATED, { mentionAcceleration: 0.95, authorsQuality: 0.85, semanticMatch: true, globalEventMatch: true, coordinationRisk: 0.05 }),
  ];
  const risk = replay(events, registry()).timeline.at(-1).risk;
  assert.equal(risk.decision, 'probe_entry');
  assert.equal(risk.positionMultiplier, 0.2);
});

test('a newly enabled freeze authority rejects the token immediately', () => {
  const events = [
    ...confirmedCandidateEvents(),
    base('freeze', 7, EventKind.AUTHORITY_CHANGED, { authority: 'freeze', active: true }),
  ];
  const risk = replay(events, registry()).timeline.at(-1).risk;
  assert.equal(risk.decision, 'reject');
  assert.deepEqual(risk.hardBlocks, ['freeze_authority_active']);
});

test('a post-launch mint is a fail-closed safety event', () => {
  const events = [
    ...confirmedCandidateEvents(),
    base('mint-after-launch', 7, EventKind.MINT_TO, { amount: '1000000', initialSupply: false }),
  ];
  const risk = replay(events, registry()).timeline.at(-1).risk;
  assert.equal(risk.decision, 'reject');
  assert.deepEqual(risk.hardBlocks, ['post_launch_mint']);
});

test('a protocol version mismatch halts the venue before a decision can be emitted', () => {
  const [event] = confirmedCandidateEvents();
  event.programVersion = 'unexpected-layout';
  assert.throws(() => replay([event], registry()), AdapterVersionMismatch);
});
